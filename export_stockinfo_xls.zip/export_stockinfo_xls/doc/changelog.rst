Changelog
=========
`10.0.2.0.0`
------------
- Total sold & Total purchased counts corrected.
- Added name for sheet.

`10.0.2.0.1`
------------
- Updated to query
